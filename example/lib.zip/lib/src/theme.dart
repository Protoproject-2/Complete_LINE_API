import 'package:flutter/material.dart';

const Color textColor = Colors.white;
final Color secondaryBackgroundColor = Colors.grey.shade300;
const Color accentColor = Color(0xFF58BF38);
const Color darkAccentColor = Color(0xFF50AF33);
